package generation.javongus.html;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlApplication.class, args);
	}

}
